declare module "*.svg" {
  const content: any;
  export default content;
}

declare module '*.woff';
declare module '*.woff2';
